// Contenido estructurado del sitio de Mercasa.
// Fuente: brief proporcionado por el cliente (Grupo Inteca). Editar aquí
// para actualizar textos/cifras sin tocar los componentes.

export const site = {
  name: "Mercasa",
  parentCompany: "Grupo Inteca",
  foundedYear: 1963,
  tagline: "Líderes en la distribución y comercialización masiva de productos de consumo en Costa Rica",
  phone: "+506 2217-3600",
  phoneHref: "tel:+50622173600",
  phonesExtra: ["2217-3818", "2217-3778"],
  emails: {
    comunicaciones: "comunicaciones.mercasa@grupointeca.com",
    rh: "rh@grupointeca.com",
  },
  address: {
    line1: "Tejar de El Guarco, Cartago, Costa Rica",
    line2: "800 m sur del Parque Industrial de Cartago",
    postalCode: "30801",
    mapQuery: "Tejar, El Guarco, Cartago, Costa Rica",
  },
  facebook: "https://www.facebook.com/mercasacr/",
};

export const navLinks = [
  { href: "#inicio", label: "Inicio" },
  { href: "#nosotros", label: "Nosotros" },
  { href: "#marcas", label: "Marcas" },
  { href: "#logistica", label: "Logística" },
  { href: "#contacto", label: "Contacto" },
];

export const stats = [
  { value: 2300, suffix: "+", label: "Códigos SKU activos en catálogo" },
  { value: 2, suffix: "", label: "Macro-CEDIs propios en operación" },
  { value: 10500, suffix: "+", label: "Posiciones de tarima bajo estándar internacional" },
  { value: 1900, suffix: "+", label: "Contenedores (TEUs) en tránsito internacional al año" },
  { value: 45, suffix: "+", label: "Proveedores aliados en 30 países" },
  { value: 2500, suffix: "", label: "Entregas comerciales cada semana" },
];

export const pillars = [
  {
    title: "Compras Internacionales",
    description:
      "Negociación y tráfico internacional con más de 45 proveedores aliados en 30 países, asegurando abastecimiento constante y competitivo.",
  },
  {
    title: "Logística Integral",
    description:
      "Gestión de punta a punta: importación, aduanas, almacenamiento y distribución, con foco en eficiencia de la cadena de suministro.",
  },
  {
    title: "Gestión de CEDIs",
    description:
      "Dos macro-centros de distribución propios con más de 10,500 posiciones de tarima y control de inventario bajo estándares internacionales.",
  },
  {
    title: "Red de Distribución Nacional",
    description:
      "Cobertura capilar en todo el país, con un promedio de 2,500 entregas comerciales semanales a supermercados, retail y comercio local.",
  },
];

// Marcas que Mercasa importa, comercializa y distribuye en Costa Rica.
// Se listan como texto (además de la foto del muro) para accesibilidad y SEO.
export const brandNames = [
  "Nature Valley", "Renata", "Matilde Vicenzi", "Fiber One", "Smucker's", "Pietrobon",
  "Pomí", "Heinz", "La Costeña", "San Marcos", "MiSabor", "Girol", "Boom Bastic",
  "Pillsbury", "Betty Crocker", "McCain", "Choice Care", "Smarty Baby", "Bebín", "Pelican", "Senior",
  "Ideal", "Selpak", "Koa", "Shave & Go", "Clinx", "BelSpá",
  "Bio EZserv", "EZlight", "EZbags", "EZserv", "EZclean", "EZtape", "B-Healthy",
  "Monday", "Thüringer", "St. Omer", "Tika",
];

export const brandPillars = [
  {
    key: "calidad",
    title: "Calidad garantizada",
    description:
      "Marcas de las mejores casas productoras internacionales, seleccionadas para garantizar excelencia en cada hogar.",
  },
  {
    key: "alianzas",
    title: "Alianzas estratégicas",
    description:
      "Relaciones comerciales duraderas con marcas reconocidas que confían en nuestra red de distribución nacional.",
  },
  {
    key: "compromiso",
    title: "Compromiso con el cliente",
    description:
      "Seguimos creciendo nuestro portafolio para llevarle siempre lo mejor a supermercados, retail y comercio local.",
  },
];

export const brandFeatures = [
  {
    key: "calidad",
    title: "Calidad",
    description: "Productos de las mejores marcas para garantizar excelencia en cada hogar.",
  },
  {
    key: "confianza",
    title: "Confianza",
    description: "Marcas reconocidas que nos permiten construir relaciones duraderas con nuestros clientes.",
  },
  {
    key: "variedad",
    title: "Variedad",
    description: "Un portafolio completo para satisfacer las necesidades de tu familia y tu negocio.",
  },
  {
    key: "compromiso",
    title: "Compromiso",
    description: "Seguimos creciendo para llevarte siempre lo mejor.",
  },
];

export const logisticsSteps = [
  {
    step: "01",
    title: "Importación Global",
    description:
      "Conexión comercial con 45+ proveedores en 30 países y gestión aduanera de alto volumen: más de 1,900 contenedores (TEUs) en tránsito internacional cada año.",
    metric: "1,900+ TEUs / año",
  },
  {
    step: "02",
    title: "Almacenamiento Inteligente",
    description:
      "Dos macro-CEDIs propios con más de 10,500 posiciones de tarima, control de inventario y estándares internacionales de administración de almacenes.",
    metric: "10,500+ posiciones de tarima",
  },
  {
    step: "03",
    title: "Distribución Capilar",
    description:
      "Despacho prioritario y red logística local con capacidad de respuesta rápida: un promedio de 2,500 entregas comerciales cada semana.",
    metric: "2,500 entregas / semana",
  },
];

export const contactChannels = [
  {
    key: "proveedor",
    title: "Nuevo Proveedor Internacional",
    description: "Alianzas comerciales, negociación de nuevas líneas y tráfico internacional.",
  },
  {
    key: "cliente",
    title: "Nuevo Cliente Local",
    description: "Supermercados, retail, mini-súper y comercio local que desean abastecerse con Mercasa.",
  },
];


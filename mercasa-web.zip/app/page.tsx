import Header from "@/components/Header";
import Hero from "@/components/Hero";
import StatsCounter from "@/components/StatsCounter";
import AboutSection from "@/components/AboutSection";
import BrandsSection from "@/components/BrandsSection";
import LogisticsTimeline from "@/components/LogisticsTimeline";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <>
      <div className="sticky top-0 z-50">
        <Header />
      </div>
      <main>
        <Hero />
        <StatsCounter />
        <AboutSection />
        <BrandsSection />
        <LogisticsTimeline />
        <ContactSection />
      </main>
      <Footer />
    </>
  );
}

"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import Image from "next/image";
import { ArrowRight, ChevronDown, Ship, Warehouse } from "lucide-react";
import { site } from "@/lib/data";
import { scrollToId } from "@/lib/utils";
import heroPhoto from "@/public/brand/hero-warehouse.jpg";

export default function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "12%"]);
  const contentY = useTransform(scrollYProgress, [0, 1], ["0%", "18%"]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <section
      id="inicio"
      ref={ref}
      className="relative flex min-h-[100svh] items-center overflow-hidden bg-navy-950 bg-noise"
    >
      {/* Backdrop: bodega/montacargas real, con overlay para legibilidad */}
      <motion.div style={{ y: bgY }} className="absolute inset-0 z-0 scale-125">
        <Image
          src={heroPhoto}
          alt="Bodega de Mercasa: montacargas moviendo tarimas entre racks de almacenamiento"
          fill
          priority
          className="object-cover brightness-[0.8] contrast-[1.02]"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-navy-950/25" />
        <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/92 to-navy-950/45" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/75 via-transparent to-navy-950/55" />
      </motion.div>

      {/* Floating accent orbs */}
      <motion.div
        className="absolute left-[8%] top-[22%] z-0 h-56 w-56 rounded-full bg-teal-500/15 blur-3xl"
        animate={{ y: [0, 24, 0], x: [0, 14, 0] }}
        transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute right-[10%] top-[12%] z-0 h-72 w-72 rounded-full bg-gold-500/10 blur-3xl"
        animate={{ y: [0, -20, 0], x: [0, -16, 0] }}
        transition={{ duration: 11, repeat: Infinity, ease: "easeInOut" }}
      />

      <motion.div
        style={{ y: contentY, opacity: contentOpacity }}
        className="relative z-10 mx-auto grid max-w-7xl gap-12 px-4 pb-24 pt-28 md:grid-cols-[1.15fr_0.85fr] md:items-center md:px-8 md:pb-32 md:pt-24"
      >
        <div>
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-medium text-teal-200 backdrop-blur-sm"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-teal-400" />
            Una empresa de {site.parentCompany} · desde {site.foundedYear}
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display text-4xl font-semibold leading-[1.08] tracking-tight text-white sm:text-5xl lg:text-6xl"
          >
            <span className="text-gradient-teal">Líderes</span> en distribución
            y comercialización masiva de productos de consumo en Costa Rica
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.22 }}
            className="mt-6 max-w-xl text-base leading-relaxed text-mist-200/80 sm:text-lg"
          >
            Importación, logística y distribución mayorista con más de 60 años
            de respaldo institucional a través de Grupo Inteca. Abastecemos
            supermercados, retail y comercio local en todo el país.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.34 }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <button
              onClick={() => scrollToId("#contacto")}
              className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-teal-500 to-teal-600 px-6 py-3.5 text-sm font-semibold text-navy-950 shadow-[0_10px_30px_-8px_rgba(26,201,191,0.6)] transition hover:brightness-110 active:scale-95"
            >
              Hágase Cliente
              <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
            </button>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="relative hidden md:block"
        >
          <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-6 shadow-2xl backdrop-blur-md">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <span className="text-xs font-medium uppercase tracking-widest text-teal-300">
                Operación en vivo
              </span>
              <span className="flex h-2 w-2 animate-pulse rounded-full bg-teal-400" />
            </div>
            <div className="mt-5 space-y-4">
              <div className="flex items-center gap-3 rounded-xl bg-white/5 p-3.5">
                <Ship className="h-5 w-5 text-teal-300" />
                <div>
                  <p className="text-sm font-semibold text-white">1,900+ TEUs / año</p>
                  <p className="text-xs text-mist-200/60">Tránsito internacional</p>
                </div>
              </div>
              <div className="flex items-center gap-3 rounded-xl bg-white/5 p-3.5">
                <Warehouse className="h-5 w-5 text-gold-400" />
                <div>
                  <p className="text-sm font-semibold text-white">10,500+ tarimas</p>
                  <p className="text-xs text-mist-200/60">2 macro-CEDIs propios</p>
                </div>
              </div>
              <div className="flex items-center gap-3 rounded-xl bg-white/5 p-3.5">
                <ArrowRight className="h-5 w-5 text-teal-300" />
                <div>
                  <p className="text-sm font-semibold text-white">2,500 entregas / semana</p>
                  <p className="text-xs text-mist-200/60">Cobertura nacional</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <motion.button
        onClick={() => scrollToId("#metricas")}
        aria-label="Desplazarse hacia abajo"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-mist-200/60 transition hover:text-white"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
      >
        <ChevronDown className="h-6 w-6" />
      </motion.button>
    </section>
  );
}

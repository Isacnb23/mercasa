"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import { ArrowRight, Award, CheckCircle2, Handshake, Package, ShoppingCart, Users } from "lucide-react";
import { brandFeatures, brandNames, brandPillars } from "@/lib/data";
import { scrollToId } from "@/lib/utils";
import wallPhoto from "@/public/brand/marcas-wall.jpg";
import logo from "@/public/brand/mercasa-logo-white.png";

const pillarIcons = { calidad: Award, alianzas: Handshake, compromiso: ShoppingCart } as const;
const featureIcons = { calidad: CheckCircle2, confianza: Users, variedad: Package, compromiso: CheckCircle2 } as const;

export default function BrandsSection() {
  return (
    <section id="marcas" className="relative bg-navy-950 bg-noise pb-24 md:pb-32">
      {/* Panel oscuro + muro de marcas nítido (sin oscurecer), unidos por una curva orgánica */}
      <div className="relative md:flex md:min-h-[620px]">
        <div className="relative z-10 flex flex-col justify-center px-4 py-16 sm:px-8 md:w-[42%] md:px-10 md:py-20 lg:w-[38%] lg:px-14">
          <Image src={logo} alt="Mercasa" className="h-7 w-auto self-start opacity-90" />

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6 }}
            className="mt-8"
          >
            <h2 className="font-display text-3xl font-semibold leading-tight tracking-tight text-white sm:text-4xl">
              Marcas que <span className="text-teal-300">construyen confianza</span>
            </h2>
            <p className="mt-5 max-w-md text-sm leading-relaxed text-mist-200/70">
              Trabajamos con marcas líderes que garantizan calidad,
              innovación y bienestar para nuestros clientes.
            </p>

            <div className="mt-8 flex flex-col gap-5">
              {brandPillars.map((pillar) => {
                const Icon = pillarIcons[pillar.key as keyof typeof pillarIcons];
                return (
                  <div key={pillar.key} className="flex items-start gap-3.5">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/10 text-teal-300">
                      <Icon className="h-5 w-5" />
                    </span>
                    <div>
                      <h3 className="text-sm font-semibold uppercase tracking-wide text-white">
                        {pillar.title}
                      </h3>
                      <p className="mt-1 text-sm leading-relaxed text-mist-200/70">
                        {pillar.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => scrollToId("#nosotros")}
              className="group mt-9 inline-flex w-fit items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-sm font-semibold text-white ring-1 ring-white/20 transition hover:bg-white/15 active:scale-95"
            >
              <ArrowRight className="h-3.5 w-3.5 transition group-hover:translate-x-0.5" />
              Conoce más sobre Nosotros
            </button>
          </motion.div>
        </div>

        {/* Muro de marcas: foto real, nítida, con esquina curva que se funde con el panel */}
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.7 }}
          className="relative h-[320px] overflow-hidden sm:h-[420px] md:-ml-16 md:h-auto md:w-[58%] md:rounded-tl-[7rem] lg:w-[62%] lg:rounded-tl-[9rem]"
        >
          <Image
            src={wallPhoto}
            alt={`Muro de marcas distribuidas por Mercasa: ${brandNames.join(", ")}`}
            fill
            placeholder="blur"
            className="object-cover object-[center_38%]"
            sizes="(min-width: 768px) 60vw, 100vw"
          />
        </motion.div>
      </div>

      {/* Franja de features: tarjeta clara sobrepuesta, como en el muro físico */}
      <div className="relative z-10 mx-4 -mt-8 sm:mx-8 md:mx-10 md:-mt-12 lg:mx-14">
        <div className="rounded-3xl bg-mist-50 px-6 py-8 shadow-2xl shadow-black/40 sm:px-8 md:px-10">
          <div className="grid gap-8 sm:grid-cols-2 md:grid-cols-4">
            {brandFeatures.map((feature, i) => {
              const Icon = featureIcons[feature.key as keyof typeof featureIcons];
              return (
                <motion.div
                  key={feature.key}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-40px" }}
                  transition={{ duration: 0.5, delay: i * 0.08 }}
                >
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-navy-900 text-teal-300">
                    <Icon className="h-5 w-5" />
                  </span>
                  <h3 className="mt-4 text-sm font-semibold uppercase tracking-wide text-navy-950">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-500">
                    {feature.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

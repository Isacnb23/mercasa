"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Ship, Truck, Warehouse } from "lucide-react";
import Reveal from "./Reveal";
import { logisticsSteps } from "@/lib/data";

gsap.registerPlugin(ScrollTrigger);

const stepIcons = [Ship, Warehouse, Truck];

export default function LogisticsTimeline() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const panelRefs = useRef<Array<HTMLDivElement | null>>([]);
  const markerRefs = useRef<Array<HTMLDivElement | null>>([]);
  const fillRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const mm = gsap.matchMedia();

      mm.add("(min-width: 768px)", () => {
        const panels = panelRefs.current.filter(Boolean) as HTMLDivElement[];
        const markers = markerRefs.current.filter(Boolean) as HTMLDivElement[];
        const total = panels.length;

        gsap.set(panels.slice(1), { autoAlpha: 0, y: 36 });
        gsap.set(markers, { backgroundColor: "rgba(255,255,255,0.06)", color: "#93f0e4" });
        if (markers[0]) gsap.set(markers[0], { backgroundColor: "#1ac9bf", color: "#060f18" });

        const tl = gsap.timeline({
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top top",
            end: `+=${total * 100}%`,
            scrub: 0.8,
            pin: true,
            anticipatePin: 1,
          },
        });

        panels.forEach((panel, i) => {
          const at = i;
          if (i < total - 1) {
            tl.to(panel, { autoAlpha: 0, y: -36, duration: 0.6 }, at + 0.55);
            if (markers[i]) {
              tl.to(
                markers[i],
                { backgroundColor: "rgba(255,255,255,0.06)", color: "#93f0e4", duration: 0.3 },
                at + 0.55
              );
            }
          }
          if (i > 0) {
            tl.to(
              panel,
              { autoAlpha: 1, y: 0, duration: 0.6 },
              at - 1 + 0.55
            );
          }
          if (i > 0 && markers[i]) {
            tl.to(
              markers[i],
              { backgroundColor: "#1ac9bf", color: "#060f18", duration: 0.3 },
              at - 1 + 0.55
            );
          }
        });

        if (fillRef.current) {
          tl.fromTo(
            fillRef.current,
            { scaleY: 0 },
            { scaleY: 1, ease: "none", duration: total },
            0
          );
        }
      });

      return () => mm.revert();
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="logistica"
      ref={sectionRef}
      className="relative overflow-hidden bg-navy-900 bg-noise py-24 md:h-screen md:py-0"
    >
      {/* Ambient backdrop, consistent with Hero / Marcas */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(90%_70%_at_85%_0%,rgba(26,201,191,0.12),transparent_55%),radial-gradient(70%_60%_at_5%_100%,rgba(219,165,58,0.08),transparent_55%)]" />
      </div>

      <div className="mx-auto flex h-full max-w-7xl flex-col justify-center px-4 md:px-8">
        <Reveal className="mb-10 max-w-2xl md:mb-14">
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-teal-400">
            Logística y cobertura
          </span>
          <h2 className="mt-4 font-display text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            El motor detrás de cada entrega
          </h2>
        </Reveal>

        <div className="grid gap-10 md:grid-cols-[auto_1fr] md:gap-14">
          {/* Progress rail */}
          <div className="hidden md:flex md:flex-col md:items-center md:gap-0">
            <div className="relative h-72 w-1 overflow-hidden rounded-full bg-white/10">
              <div
                ref={fillRef}
                className="absolute left-0 top-0 h-full w-full origin-top scale-y-0 rounded-full bg-gradient-to-b from-teal-400 to-teal-600"
              />
            </div>
          </div>

          {/* Desktop pinned panels */}
          <div className="relative hidden min-h-[340px] md:block">
            {logisticsSteps.map((step, i) => {
              const Icon = stepIcons[i];
              return (
                <div
                  key={step.step}
                  ref={(el) => {
                    panelRefs.current[i] = el;
                  }}
                  className="absolute inset-0 flex flex-col justify-center"
                >
                  <div className="max-w-xl rounded-3xl border border-white/10 bg-white/[0.04] p-8 shadow-2xl shadow-black/20 backdrop-blur-sm sm:p-10">
                    <div className="mb-6 flex items-center gap-4">
                      <div
                        ref={(el) => {
                          markerRefs.current[i] = el;
                        }}
                        className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl"
                      >
                        <Icon className="h-6 w-6" />
                      </div>
                      <span className="text-xs font-semibold uppercase tracking-[0.2em] text-mist-200/50">
                        Paso {step.step}
                      </span>
                    </div>
                    <h3 className="font-display text-2xl font-semibold text-white sm:text-3xl">
                      {step.title}
                    </h3>
                    <p className="mt-4 text-base leading-relaxed text-mist-200/70">
                      {step.description}
                    </p>
                    <span className="mt-6 inline-flex w-fit items-center rounded-full bg-teal-500/15 px-4 py-1.5 text-sm font-semibold text-teal-300">
                      {step.metric}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Mobile stacked fallback */}
          <div className="flex flex-col gap-6 md:hidden">
            {logisticsSteps.map((step, i) => {
              const Icon = stepIcons[i];
              return (
                <Reveal
                  key={step.step}
                  delay={i * 0.05}
                  className="rounded-3xl border border-white/10 bg-white/[0.04] p-6 shadow-xl shadow-black/10 backdrop-blur-sm"
                >
                  <div className="mb-4 flex items-center gap-3">
                    <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-teal-500/15 text-teal-300">
                      <Icon className="h-5 w-5" />
                    </span>
                    <span className="text-xs font-semibold uppercase tracking-[0.2em] text-mist-200/50">
                      Paso {step.step}
                    </span>
                  </div>
                  <h3 className="font-display text-xl font-semibold text-white">
                    {step.title}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-mist-200/70">
                    {step.description}
                  </p>
                  <span className="mt-4 inline-flex w-fit items-center rounded-full bg-teal-500/15 px-3 py-1 text-xs font-semibold text-teal-300">
                    {step.metric}
                  </span>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

import { MapPin, Mail, Phone, Truck } from "lucide-react";
import { navLinks, site } from "@/lib/data";

function FacebookIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
      <path d="M13.5 9H15V6.5h-1.5C11.6 6.5 10 8.1 10 10.2V12H8v2.5h2V21h2.5v-6.5H15l.5-2.5h-3v-1.6c0-.6.4-1 1-1Z" />
    </svg>
  );
}

export default function Footer() {
  return (
    <footer className="relative bg-ink pt-16 text-mist-200/70">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <div className="grid gap-10 border-b border-white/10 pb-12 md:grid-cols-[1.3fr_0.8fr_1fr]">
          <div>
            <div className="flex items-center gap-2.5 text-white">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-400 to-teal-700">
                <Truck className="h-5 w-5 text-navy-950" />
              </span>
              <span className="font-display text-lg font-semibold">
                {site.name}
              </span>
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed">
              Empresa de {site.parentCompany}, fundada en {site.foundedYear}.
              Importación, logística y distribución mayorista de consumo
              masivo en todo Costa Rica.
            </p>
            <a
              href={site.facebook}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 inline-flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-mist-200/70 transition hover:bg-white/10 hover:text-white"
              aria-label="Mercasa en Facebook"
            >
              <FacebookIcon className="h-4 w-4" />
            </a>
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-white/60">
              Navegación
            </p>
            <ul className="mt-4 space-y-2.5 text-sm">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="transition hover:text-white">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-white/60">
              Contacto
            </p>
            <ul className="mt-4 space-y-3 text-sm">
              <li className="flex items-start gap-2.5">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-teal-400" />
                <span>{site.address.line1}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="h-4 w-4 shrink-0 text-teal-400" />
                <a href={site.phoneHref} className="hover:text-white">
                  {site.phone}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="h-4 w-4 shrink-0 text-teal-400" />
                <a href={`mailto:${site.emails.comunicaciones}`} className="hover:text-white">
                  {site.emails.comunicaciones}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col gap-3 py-6 text-xs text-mist-200/50 md:flex-row md:items-center md:justify-between">
          <p>
            © {new Date().getFullYear()} {site.name} · {site.parentCompany}. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}

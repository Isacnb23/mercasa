"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Image from "next/image";
import { Menu, X } from "lucide-react";
import { navLinks } from "@/lib/data";
import { cn, scrollToId } from "@/lib/utils";
import logo from "@/public/brand/mercasa-logo-white.png";

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNav = (e: React.MouseEvent, href: string) => {
    e.preventDefault();
    setOpen(false);
    scrollToId(href);
  };

  const linkClass =
    "font-display text-[15px] font-medium text-white/85 transition hover:text-white [text-shadow:0_1px_3px_rgba(0,0,0,0.45)]";

  return (
    <header className="sticky top-0 z-50 w-full">
      {/* Liquid glass bar — full-bleed, flush against the top edge */}
      <div
        className={cn(
          "relative w-full overflow-hidden border-b border-white/10 bg-gradient-to-r from-navy-700/95 via-navy-800/95 to-teal-800/90 backdrop-blur-2xl backdrop-saturate-125 transition-all duration-500",
          scrolled
            ? "from-navy-800/98 via-navy-900/98 to-teal-900/95 shadow-[0_10px_30px_-10px_rgba(6,15,24,0.6)]"
            : ""
        )}
      >
        {/* specular highlight */}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/40 to-transparent" />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-white/[0.06] via-transparent to-black/10" />

        <div className="relative mx-auto grid max-w-7xl grid-cols-[auto_1fr_auto] items-center gap-4 px-4 py-3.5 md:px-8">
          {/* Logo (left) */}
          <a
            href="#inicio"
            onClick={(e) => handleNav(e, "#inicio")}
            aria-label="Mercasa — Inicio"
            className="flex shrink-0 items-center transition active:scale-95"
          >
            <Image src={logo} alt="Mercasa" priority className="h-7 w-auto md:h-8" />
          </a>

          {/* Nav links (desktop, centered) */}
          <nav className="hidden items-center justify-center gap-8 md:flex">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleNav(e, link.href)}
                className={linkClass}
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Hamburger (mobile) */}
          <button
            className="col-start-3 flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-white transition hover:bg-white/10 md:hidden"
            aria-label={open ? "Cerrar menú" : "Abrir menú"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile dropdown */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
            className="absolute inset-x-0 top-full overflow-hidden border-b border-white/10 bg-gradient-to-br from-navy-800/98 via-navy-900/98 to-teal-900/95 shadow-[0_16px_40px_-8px_rgba(6,15,24,0.7)] backdrop-blur-2xl backdrop-saturate-125 md:hidden"
          >
            <div className="flex flex-col gap-1 p-3">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => handleNav(e, link.href)}
                  className="rounded-2xl px-4 py-3 text-base font-medium text-white/90 transition hover:bg-white/10"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

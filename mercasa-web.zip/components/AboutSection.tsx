"use client";

import { CheckCircle2 } from "lucide-react";
import Reveal, { RevealGroup, RevealItem } from "./Reveal";
import { pillars, site } from "@/lib/data";

export default function AboutSection() {
  return (
    <section id="nosotros" className="relative bg-mist-50 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <div className="grid gap-16 md:grid-cols-2 md:gap-12">
          <div>
            <Reveal>
              <span className="text-xs font-semibold uppercase tracking-[0.2em] text-teal-600">
                Nosotros
              </span>
              <h2 className="mt-4 font-display text-3xl font-semibold tracking-tight text-navy-950 sm:text-4xl">
                Más de 60 años de respaldo institucional
              </h2>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mt-6 text-base leading-relaxed text-slate-700">
                Mercasa opera bajo el respaldo de <strong>{site.parentCompany}</strong>,
                corporación de capital privado fundada en {site.foundedYear} y
                líder en la región. Esa trayectoria nos permite sostener una
                operación de distribución mayorista robusta, confiable y en
                constante modernización.
              </p>
            </Reveal>
            <Reveal delay={0.18}>
              <p className="mt-4 text-base leading-relaxed text-slate-700">
                Nuestro trabajo se sostiene en tres frentes: eficiencia en la
                cadena de suministro, excelencia en compras de tráfico
                internacional y precisión en la administración de almacenes —
                de forma que cada producto llegue a tiempo, en condiciones
                óptimas, a cada punto de venta del país.
              </p>
            </Reveal>

            <Reveal delay={0.26} className="mt-8 flex flex-wrap gap-3">
              {[
                "Capital humano de 201 a 500 colaboradores",
                "Estándares internacionales de operación",
                "Cobertura logística nacional",
              ].map((item) => (
                <span
                  key={item}
                  className="inline-flex items-center gap-2 rounded-full border border-navy-900/10 bg-white px-4 py-2 text-xs font-medium text-navy-800 shadow-sm"
                >
                  <CheckCircle2 className="h-3.5 w-3.5 text-teal-600" />
                  {item}
                </span>
              ))}
            </Reveal>
          </div>

          <RevealGroup className="grid gap-4 sm:grid-cols-2">
            {pillars.map((pillar) => (
              <RevealItem
                key={pillar.title}
                className="group rounded-2xl border border-navy-900/8 bg-white p-6 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-teal-900/10"
              >
                <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500/15 to-navy-900/5 text-teal-700 transition group-hover:scale-110">
                  <span className="font-display text-lg font-semibold">
                    {pillar.title.charAt(0)}
                  </span>
                </div>
                <h3 className="font-display text-lg font-semibold text-navy-950">
                  {pillar.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-500">
                  {pillar.description}
                </p>
              </RevealItem>
            ))}
          </RevealGroup>
        </div>
      </div>
    </section>
  );
}

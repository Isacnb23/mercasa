"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  CheckCircle2,
  Clock,
  Loader2,
  Mail,
  MapPin,
  Phone,
  Send,
} from "lucide-react";
import Reveal from "./Reveal";
import { contactChannels, site } from "@/lib/data";
import { cn } from "@/lib/utils";

type Status = "idle" | "loading" | "success" | "error";

export default function ContactSection() {
  const [channel, setChannel] = useState(contactChannels[1].key);
  const [status, setStatus] = useState<Status>("idle");

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus("loading");
    const formData = new FormData(e.currentTarget);
    formData.set("canal", channel);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        body: formData,
      });
      if (!res.ok) throw new Error("request failed");
      setStatus("success");
      e.currentTarget.reset();
    } catch {
      setStatus("error");
    }
  };

  const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(
    site.address.mapQuery
  )}&output=embed`;

  return (
    <section id="contacto" className="relative bg-mist-50 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-teal-600">
            Contacto
          </span>
          <h2 className="mt-4 font-display text-3xl font-semibold tracking-tight text-navy-950 sm:text-4xl">
            Hablemos de negocios
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-8 lg:grid-cols-[1fr_1.1fr]">
          {/* Info + map */}
          <Reveal className="space-y-6">
            <div className="overflow-hidden rounded-3xl border border-navy-900/8 shadow-sm">
              <iframe
                title="Ubicación de Mercasa en El Guarco, Cartago"
                src={mapSrc}
                className="h-64 w-full grayscale-[15%] sm:h-72"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>

            <div className="space-y-4 rounded-3xl border border-navy-900/8 bg-white p-6 shadow-sm">
              <InfoRow icon={MapPin} title="Sede central (CEDI)">
                {site.address.line1}
                <br />
                {site.address.line2} · CP {site.address.postalCode}
              </InfoRow>
              <InfoRow icon={Phone} title="Teléfono central">
                <a href={site.phoneHref} className="hover:text-teal-700">
                  {site.phone}
                </a>{" "}
                · {site.phonesExtra.join(" / ")}
              </InfoRow>
              <InfoRow icon={Mail} title="Correos oficiales">
                <a href={`mailto:${site.emails.comunicaciones}`} className="hover:text-teal-700">
                  {site.emails.comunicaciones}
                </a>
                <br />
                <a href={`mailto:${site.emails.rh}`} className="hover:text-teal-700">
                  {site.emails.rh}
                </a>{" "}
                (RH)
              </InfoRow>
              <InfoRow icon={Clock} title="Horario de atención">
                Lunes a viernes, horario de oficina
              </InfoRow>
            </div>
          </Reveal>

          {/* Form */}
          <Reveal delay={0.1}>
            <form
              onSubmit={handleSubmit}
              className="rounded-3xl border border-navy-900/8 bg-white p-6 shadow-sm sm:p-8"
            >
              <div className="mb-6 grid grid-cols-2 gap-2 rounded-2xl bg-mist-100 p-1.5">
                {contactChannels.map((c) => (
                  <button
                    type="button"
                    key={c.key}
                    onClick={() => setChannel(c.key)}
                    className={cn(
                      "rounded-xl px-3 py-2.5 text-sm font-semibold transition",
                      channel === c.key
                        ? "bg-white text-navy-950 shadow-sm"
                        : "text-slate-500 hover:text-navy-800"
                    )}
                  >
                    {c.title}
                  </button>
                ))}
              </div>
              <p className="mb-6 text-sm text-slate-500">
                {contactChannels.find((c) => c.key === channel)?.description}
              </p>

              <div className="grid gap-5 sm:grid-cols-2">
                <Field label={channel === "proveedor" ? "Empresa / proveedor" : "Nombre del negocio"} name="empresa" required />
                <Field label="Nombre de contacto" name="nombre" required />
                <Field label="Correo electrónico" name="correo" type="email" required />
                <Field label="Teléfono" name="telefono" type="tel" required />
                {channel === "proveedor" && (
                  <div className="sm:col-span-2">
                    <Field label="País de origen" name="pais" />
                  </div>
                )}
                <div className="sm:col-span-2">
                  <label className="mb-1.5 block text-xs font-medium text-slate-500">
                    Mensaje
                  </label>
                  <textarea
                    name="mensaje"
                    rows={4}
                    required
                    className="w-full resize-none rounded-xl border border-navy-900/10 bg-mist-50 px-4 py-3 text-sm text-navy-950 outline-none transition focus:border-teal-500"
                  />
                </div>
              </div>

              <motion.button
                type="submit"
                disabled={status === "loading"}
                whileTap={{ scale: 0.97 }}
                className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-navy-800 to-navy-900 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-navy-900/20 transition hover:brightness-110 disabled:opacity-60"
              >
                {status === "loading" ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : status === "success" ? (
                  <CheckCircle2 className="h-4 w-4" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
                {status === "success" ? "¡Mensaje enviado!" : "Enviar mensaje"}
              </motion.button>

              {status === "error" && (
                <p className="mt-3 text-xs text-red-600">
                  No se pudo enviar el mensaje. Intenta de nuevo o llámanos al {site.phone}.
                </p>
              )}
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function InfoRow({
  icon: Icon,
  title,
  children,
}: {
  icon: React.ElementType;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex gap-3.5">
      <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-teal-600/10 text-teal-700">
        <Icon className="h-4 w-4" />
      </span>
      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
          {title}
        </p>
        <p className="mt-0.5 text-sm leading-relaxed text-navy-900">{children}</p>
      </div>
    </div>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-medium text-slate-500">
        {label}
      </label>
      <input
        type={type}
        name={name}
        required={required}
        className="w-full rounded-xl border border-navy-900/10 bg-mist-50 px-4 py-3 text-sm text-navy-950 outline-none transition focus:border-teal-500"
      />
    </div>
  );
}
